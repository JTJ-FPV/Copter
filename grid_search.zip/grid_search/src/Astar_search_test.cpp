#include <ros/ros.h>
#include "grid_search/Astar_search.h"
#include <geometry_msgs/PoseStamped.h>
#include <nav_msgs/Odometry.h>

#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/exact_time.h>

#include <visualization_msgs/MarkerArray.h>
#include <visualization_msgs/Marker.h>

typedef message_filters::sync_policies::ExactTime<nav_msgs::Odometry, geometry_msgs::PoseStamped> MySyncPolicy_odom_target;

CUADC::AstarPathFinder * astar_ptr;

ros::Publisher path_pub;

message_filters::Subscriber<nav_msgs::Odometry> odom_data;
message_filters::Subscriber<geometry_msgs::PoseStamped> target_data;
message_filters::Synchronizer<MySyncPolicy_odom_target> sync_odom_target(MySyncPolicy_odom_target(1), odom_data, target_data);

Eigen::Vector3d start, target;
std::vector<Eigen::Vector3d> path;

visualization_msgs::Marker node_vis; 

void visGridPath(std::vector<Eigen::Vector3d> path)
{
    node_vis.points.clear();
    geometry_msgs::Point pt;
    for(auto &p:path)
    {
        pt.x = p.x();
        pt.y = p.y();
        pt.z = p.z();

        node_vis.points.push_back(pt);
    }
    path_pub.publish(node_vis);
}

void odom_targetCallback(const nav_msgs::OdometryConstPtr &odom , const geometry_msgs::PoseStampedConstPtr &targ)
{
    path.clear();
    start << odom->pose.pose.position.x, odom->pose.pose.position.y, odom->pose.pose.position.z;
    target << targ->pose.position.x, targ->pose.position.y, targ->pose.position.z;
    astar_ptr->AstarGraphSearch(start, target, CUADC::AstarHeu::DIALOG);
    astar_ptr->getPath(path);
    ROS_INFO("find path");
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "PathFinding");
    ros::NodeHandle nh;
    path_pub = nh.advertise<visualization_msgs::Marker>("a_star_path", 100);
    sync_odom_target.registerCallback(boost::bind(&odom_targetCallback, _1, _2));
    CUADC::MapPtr map_ptr;
    map_ptr = new CUADC::Map();
    map_ptr->initMap(nh);
    astar_ptr = new CUADC::AstarPathFinder(map_ptr);

    node_vis.header.frame_id = astar_ptr->map_->mp_.frame_id_;
    node_vis.header.stamp = ros::Time::now();

    node_vis.type = visualization_msgs::Marker::CUBE_LIST;  // 立方体
    node_vis.action = visualization_msgs::Marker::ADD;
    node_vis.id = 0;

    node_vis.pose.orientation.x = 0.0;
    node_vis.pose.orientation.y = 0.0;
    node_vis.pose.orientation.z = 0.0;
    node_vis.pose.orientation.w = 1.0;

    node_vis.color.a = 1.0;
    node_vis.color.r = 1.0;
    node_vis.color.g = 1.0;
    node_vis.color.b = 1.0;

    node_vis.scale.x = astar_ptr->map_->mp_.resolution_;
    node_vis.scale.y = astar_ptr->map_->mp_.resolution_;
    node_vis.scale.z = astar_ptr->map_->mp_.resolution_;

    ros::spin();
    delete astar_ptr;
    delete map_ptr;
    return 0;
}
